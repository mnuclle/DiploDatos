Jorge/Franco, 

Se adjunta una versi�n PDF de la notebook.

Por cuestiones de est�tica del formato en la exportaci�n a PDF tambi�n se adjunta la notebook y una serie de archivos .csv
que contienen el resumen de las distintas pruebas realizadas para cada modelo con las variaciones en hiperpar�metros y par�metros.

La correcci�n puede ser realizada tanto en el PDF como en la notebook.

Muchas gracias
Gabriel Tagle.